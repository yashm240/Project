module.exports ={
    ROUTES:{
        HOME:'/',
        USER:{
            LOGIN:'/login',
            REGISTER:'/register'
        },
        BLOG:{
            COMPOSE:'/compose',
            READ_BLOG_BY_CATEGORY:'/read-blog-by-category',
            READ_BLOG_BY_USER:'/read-blog-by-user'
        }
    },
    STATUS_CODE:{
        SUCCESS:200,
        INTERNAL_SERVER_ERROR:500,
        NOT_FOUND : 404

    },
    SCHEMAS:{
        USERS:'users',
        BLOGS:'blog'
    }
}