const connection = require("../connection");
const { SchemaTypes } = require("mongoose");
const {USERS} = require('../../utils/config/app-constants').SCHEMAS
const joi = require('joi');
const Schema = connection.Schema;

const userSchema = new Schema({
  name: { type: SchemaTypes.String, required: [true, 'Please enter Name'] },
  email: { type: SchemaTypes.String, required:[true, 'Please enter email'], unique: true },
  password: { type: SchemaTypes.String, required: [true, 'Please enter password'] },
});

const UserModel = connection.model(USERS, userSchema); // Schema --> collection 
const validateUser = (user)=>{
    const schema = joi.object({
      name: joi.string().required(),
      email:joi.string().email().min(5).max(50).required(),
      pass:joi.string().min(8).max(30).required()
    })
    return schema.validate(user)
}


module.exports = {UserModel
  ,validateUser,
};