const connection = require("../connection");
const { SchemaTypes } = require("mongoose");


const Schema = connection.Schema;
const blogSchema = new Schema({
  title: { type: SchemaTypes.String, required: true },
  body: { type: SchemaTypes.String, required: true },
  category: { type: SchemaTypes.String, required: true },
  date: { type: SchemaTypes.Date, required: true },
  email: { type: SchemaTypes.String, required: true, ref:'users' },
});
const blogModel = connection.model("blogs", blogSchema);
module.exports = blogModel;