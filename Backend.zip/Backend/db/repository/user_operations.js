const {UserModel} = require("../models/user_schema");
module.exports = {
  async add(userObject, response) {
    console.log(
      "adding data in db",
      userObject,
      userObject.name,
      userObject.email,
      userObject.pass
    );

    try {
      const newuser = new UserModel({
        name: userObject.name,
        email: userObject.email,
        password: userObject.pass,
      });
      const a1 = await newuser.save();
      console.log("this is a1", a1);
      // response.json(a1)
      response.send("Registration Done");
    } catch (err) {
      console.log("got an error", err);
      response.send("Registration Failed");
    }
    // return UserModel.create({
    //   'name': userObject.name,
    //   'email': userObject.email,
    //   'password': userObject.pass
    // });
  
    // console.log(
    //   "adding data in db",
    //   userObject,
    //   userObject.name,
    //   userObject.email,
    //   userObject.pass
    // );

    // try {
    //   const newuser = new UserModel({
    //     name: userObject.name,
    //     email: userObject.email,
    //     password: userObject.pass,
    //   });
    //   const a1 = await newuser.save();
    //   console.log("this is a1", a1);
    //   // response.json(a1)
    //   response.send("Registration Done");
    // } catch (err) {
    //   console.log("got an error", err);
    //   response.send("Registration Failed");
    },
    // return UserModel.create({
    //   'name': userObject.name,
    //   'email': userObject.email,
    //   'password': userObject.pass
    // });
  
     read(userObject,response) {
      console.log(userObject);
       UserModel.findOne(
        { email: userObject.email, password: userObject.pass },
        function (err, result) {
          if (err) {
            console.log("phatt gya phir ", err);
          } else {
            if (result == null) {
              console.log("record not found",result);
              response.json({ message: "Email/Password is wrong" });
    
            } else {
              console.log("Hello ", result.name,result);
              response.json({ message: "Hello " + result.name });
              
            }
          }
    // console.log(userObject);
    // UserModel.findOne(
    //   { email: userObject.email, password: userObject.pass },
    //   function (err, result) {
    //     if (err) {
    //       console.log("phatt gya phir ", err);
    //     } else {
    //       if (result == null) {
    //         console.log("record not found",result);
    //         response.json({ message: "Email/Password is wrong" });
    //       } else {
    //         console.log("Hello ", result.name,result);
    //         response.json({ message: "Hello " + result.name });
    //       }
    //     }

        //   {
        //     console.log(doc)
        //     // if (err) {
        //     //   response.json({ message: "Not Registered" });
        //     //   console.log("entry not found" + err);
        //     // } else if (doc) {
        //     //   response.json({ message: "Welcome " + doc.name });
        //     //   console.log("record found , login successfull");
        //     // } else {
        //     //   response.json({ message: "Not Registered" });
        //     //   console.log("record not found , no error");
        //     // }
        //   }
        // );
      })}}
//     );
//   },
//   update(userObject) {
//     UserModel.findOneAndUpdate(
//       { userid: userObject.userid },
//       { password: userObject.password }
//     );
//   },
//   remove(userObject) {},
// }
