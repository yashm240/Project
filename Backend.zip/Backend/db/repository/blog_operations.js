const blogModel = require("../models/blog_schema");
const mongoose = require("mongoose");

module.exports = {
  
  async add(blogObject,response) {
    try{
      const newblog = new blogModel({
        title: blogObject.title,
        body: blogObject.body,
        category: blogObject.category,
        email: blogObject.email,
        date: new Date(),
      })
    const doc = await newblog.save();
    response.send("composed")
  }catch (err) {
    console.log("error aagya ",err)
    response.send("Blog Not Composed, an Error occured")}},
  async read(blogObject) {
    console.log("Category is", blogObject.category);
    if (blogObject.category == "all") {
      const docs = await blogModel.find({});
      return docs;
    } else {
      const docs = await blogModel.find({category:blogObject.category});
      return docs;
    }
  },
  async readbyuser(blogObject){
    console.log("User Email id is ",blogObject)
    const docs = await blogModel.find({email:blogObject});
    return docs;
  }
};