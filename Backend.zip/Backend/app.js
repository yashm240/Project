const express = require("express");
// const chalk = require('chalk'); // Terminal Style
const app = express();
const dotenv  = require('dotenv'); // env file read
dotenv.config(); // read all the key from .env file and load in process.env

const {HOME} = require('./utils/config/app-constants').ROUTES;
app.use(express.static("public")); // Static Content
app.use(express.json());
const cors = require("cors");
app.use(cors());
app.use(HOME, require("./api/v1/routes/blog"));
app.use(HOME, require("./api/v1/routes/user"));
const server = app.listen(process.env.PORT, (err) => {
  if (err) {
    console.log('Server Crash '+JSON.stringify(err));
  } else {
    console.log('Server Started at '+server.address().port);
  }
});