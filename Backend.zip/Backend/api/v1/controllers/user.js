const userOperations = require("../../../db/repository/user_operations");

module.exports = {
  Register(request, response) {
    const userObject = request.body;
    console.log("response body is", userObject);
    userOperations.add(userObject, response);
    console.log("after adding in db", userObject);
  }
  ,
  Login(request, response) {
    const userObject = request.body;
    console.log("response body is", userObject);
    userOperations.read(userObject,response);
    
    // console.log("haanji ")
    // response.json({message:x})
    console.log("after adding in db", userObject);
    // response.json({userid:userObject.userid , pass:userObject.pass})
  }
};
