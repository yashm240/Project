const blogOperations = require("../../../db/repository/blog_operations");
const blogModel = require("../../../db/models/blog_schema");
const {UserModel} = require("../../../db/models/user_schema");


const {SUCCESS,INTERNAL_SERVER_ERROR, NOT_FOUND} =  require('../../../utils/config/app-constants').STATUS_CODE;
const language = require('../../../utils/i18n/en.json');

module.exports = {
  async Compose(request, response) {
    const userObject=request.body;
    console.log("compose main userobject is ",userObject)
    if (UserModel.findOne(
      { email: userObject.email, password: userObject.pass })==null){
        response.send("you are not registered")
    let newblog = new blogModel({
      title: request.body.title,
      body: request.body.body,
      category: request.body.category,
      email: request.body.email,
      date: new Date()
    });
    const result = await blogOperations.add(newblog,response);
    // try{
    //   if(result && result._id){
    //     response.status(SUCCESS).json({message:language['blog.added']})
    //   }
    //   else{
    //     response.status(NOT_FOUND).json({message:language['blog.added.fail']})
    //   }
    // }
    // catch(err){
    //   response.status(INTERNAL_SERVER_ERROR).json({messgae:language['server.error']});
    //   console.log('Add to cart ',err)
    // }
  }
  else{
    let newblog = new blogModel({
      title: request.body.title,
      body: request.body.body,
      category: request.body.category,
      email: request.body.email,
      date: new Date()
    });
    const result = await blogOperations.add(newblog);
    try{
      if(result && result._id){
        response.status(SUCCESS).json({message:language['blog.added']})
      }
      else{
        response.status(NOT_FOUND).json({message:language['blog.added.fail']})
      }
    }
    catch(err){
      response.status(INTERNAL_SERVER_ERROR).json({messgae:language['server.error']});
      console.log('Add to cart ',err)
    }
  }},
  async ReadbyCategory(request, response){
    const category=request.query;//yaha pe category aaegi aur jab readall karna hota tab iski value * aaegi
    console.log("yaha hai readbycategory of controller ",category )
    const result = await blogOperations.read(category);
    try{
      if (result && result.length>0){
        response.status(SUCCESS).json(result)
      }
      else{
        response.status(NOT_FOUND).json({blogs:result});
    }
    }
    catch(err){
      response.status(INTERNAL_SERVER_ERROR).json({message:language['server.error']});
      console.log('View Blogs ',err);
  }
  },
  async ReadbyUser(request,response){
    const user=request.query.email;
    const result = await blogOperations.readbyuser(user);
    
    try{
      if (result && result.length>0){
        response.status(SUCCESS).json({blogs:result})
      }
      else{
        response.status(NOT_FOUND).json({blogs:result});
    }
    }
    catch(err){
      response.status(INTERNAL_SERVER_ERROR).json({message:language['server.error']});
      console.log('View Blogs ',err);
  }
  }
};
