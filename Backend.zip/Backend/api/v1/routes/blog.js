const express = require("express");
const blogRoutes = express.Router();
const {COMPOSE,READ_BLOG_BY_CATEGORY,READ_BLOG_BY_USER}=require('../../../utils/config/app-constants').ROUTES.BLOG
const blogController = require("../controllers/blog.js");


blogRoutes.get(READ_BLOG_BY_CATEGORY, blogController.ReadbyCategory);
blogRoutes.post(READ_BLOG_BY_USER, blogController.ReadbyUser);
blogRoutes.post(COMPOSE, blogController.Compose);

module.exports = blogRoutes;
