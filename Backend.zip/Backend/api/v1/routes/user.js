const express = require('express')
const userRoutes = express.Router();
const {LOGIN,REGISTER}= require('../../../utils/config/app-constants').ROUTES.USER
const userController = require('../controllers/user')
const validateMiddleware = require('../../../utils/middlewares/schema-validator')
const validateUser = require('../../../db/models/user_schema').validateUser
userRoutes.post(LOGIN,userController.Login)
userRoutes.post(REGISTER,
    [validateMiddleware(validateUser)],
    userController.Register)
module.exports=userRoutes;